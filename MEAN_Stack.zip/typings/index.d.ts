/// <reference path="globals/stripe-node/index.d.ts" />
