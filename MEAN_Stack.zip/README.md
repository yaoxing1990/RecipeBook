# Recipe Book 2.0

The app is designed to help user to add selected recipes on the website to his/her own recipe book. The front end is based on Angular 2, and the backend is based on Node.js/Express.js. User credentials and recipes are stored in MongoDB database. The app is deployed on AWS Elastic beanstalk and the database is deployed on mLab.

In progress...
